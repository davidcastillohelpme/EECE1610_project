module Game2ElectricBoogaloo {
	requires java.desktop;
}